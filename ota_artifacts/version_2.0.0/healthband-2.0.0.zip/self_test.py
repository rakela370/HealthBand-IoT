"""HealthBand release self-test."""

from pathlib import Path
import sys


RELEASE_ROOT = Path(__file__).resolve().parent
PAYLOAD_ROOT = RELEASE_ROOT / "payload"

sys.path.insert(
    0,
    str(PAYLOAD_ROOT),
)


def main() -> None:
    """Verify release imports and basic simulated sensing."""

    from device_simulator.core.device_state import DeviceState
    from device_simulator.sensors.sensor_manager import SensorManager
    from device_simulator.simulation.scenario_engine import ScenarioEngine

    assert DeviceState.MONITORING.value == "MONITORING"

    engine = ScenarioEngine()

    manager = SensorManager(
        random_seed=123,
        software_version='2.0.0',
    )

    snapshot = manager.read_all(
        engine.get_context(),
        2.0,
    )

    assert "heartRateBpm" in snapshot.measurements
    assert "totalDailySteps" in snapshot.measurements
    assert "batteryPercentage" in snapshot.measurements

    capabilities = ['CALORIE_ESTIMATION', 'HEART_RATE_MONITORING', 'LOCAL_ANALYTICS', 'SKIN_TEMPERATURE_MONITORING', 'SPO2_MONITORING', 'STEP_COUNTING']

    if "SPO2_MONITORING" in capabilities:
        from device_simulator.sensors.spo2_sensor import SpO2Sensor

        assert SpO2Sensor is not None
        assert "oxygenSaturationPercentage" in snapshot.measurements
        assert snapshot.sensor_status.get("spo2") == "OK"

    if "CALORIE_ESTIMATION" in capabilities:
        from device_simulator.analytics.calorie_estimator import CalorieEstimator

        assert CalorieEstimator is not None

    print("SELF_TEST_OK")


if __name__ == "__main__":
    main()
