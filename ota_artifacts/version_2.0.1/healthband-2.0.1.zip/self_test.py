"""Intentional HealthBand OTA rollback demonstration self-test."""


def main() -> None:
    """Fail intentionally to demonstrate automatic OTA rollback."""

    raise RuntimeError(
        "INTENTIONAL_DEMO_SELF_TEST_FAILURE"
    )


if __name__ == "__main__":
    main()
