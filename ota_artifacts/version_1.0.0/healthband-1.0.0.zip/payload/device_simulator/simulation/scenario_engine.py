"""Scenario engine for the HealthBand version-1 simulator."""

from dataclasses import replace

from device_simulator.simulation.scenario import (
    ActivityLevel,
    ScenarioContext,
    SimulationScenario,
)
from device_simulator.simulation.user_profile import UserProfile


class ScenarioEngine:
    """Provide physiological parameters plus independent technical overlays."""

    _TECHNICAL_SCENARIOS = frozenset(
        {
            SimulationScenario.SENSOR_FAILURE,
            SimulationScenario.LOW_BATTERY,
            SimulationScenario.NETWORK_OUTAGE,
        }
    )

    def __init__(
        self,
        user_profile: UserProfile | None = None,
    ) -> None:
        self.user_profile = user_profile or UserProfile()
        self._current_scenario = SimulationScenario.RESTING
        self._failed_sensor_name: str | None = None
        self._force_low_battery = False

    @property
    def current_scenario(self) -> SimulationScenario:
        """Return the active physiological scenario."""

        return self._current_scenario

    def set_scenario(
        self,
        scenario: SimulationScenario,
        failed_sensor_name: str | None = None,
    ) -> None:
        """Change activity or apply one technical overlay.

        NETWORK_OUTAGE, SENSOR_FAILURE and LOW_BATTERY are device conditions,
        not human activities. Applying one therefore leaves RUNNING/WALKING/
        SLEEPING/etc. unchanged.
        """

        if scenario == SimulationScenario.SENSOR_FAILURE:
            self._failed_sensor_name = failed_sensor_name or "heart_rate"
            return

        if scenario == SimulationScenario.LOW_BATTERY:
            self._force_low_battery = True
            return

        if scenario == SimulationScenario.NETWORK_OUTAGE:
            return

        if scenario in self._TECHNICAL_SCENARIOS:
            return

        self._current_scenario = scenario

        # A newly selected physical activity clears the one-shot forced-low
        # battery overlay. A failed sensor is deliberately not healed here;
        # it remains failed until RESTORE_SENSOR is issued.
        self._force_low_battery = False
        self._failed_sensor_name = None

    def clear_sensor_failure(
        self,
        sensor_name: str | None = None,
    ) -> None:
        """Clear the technical sensor-failure overlay only."""

        if (
            sensor_name is None
            or self._failed_sensor_name == sensor_name
        ):
            self._failed_sensor_name = None

    def get_context(self) -> ScenarioContext:
        """Build version-1 sensor parameters for the active activity."""

        profile = self.user_profile
        base_temperature = profile.base_skin_temperature_c

        profiles = {
            SimulationScenario.SLEEPING: ScenarioContext(
                scenario=SimulationScenario.SLEEPING,
                activity_level=ActivityLevel.SLEEPING,
                heart_rate_target_bpm=profile.sleeping_heart_rate_bpm,
                skin_temperature_target_c=base_temperature + 0.45,
                steps_per_minute=0.0,
                battery_drain_multiplier=0.80,
                heart_rate_time_constant_sec=70.0,
                cadence_time_constant_sec=8.0,
                skin_temperature_time_constant_sec=600.0,
            ),
            SimulationScenario.RESTING: ScenarioContext(
                scenario=SimulationScenario.RESTING,
                activity_level=ActivityLevel.RESTING,
                heart_rate_target_bpm=profile.resting_heart_rate_bpm,
                skin_temperature_target_c=base_temperature,
                steps_per_minute=0.0,
                battery_drain_multiplier=1.0,
                heart_rate_time_constant_sec=55.0,
                cadence_time_constant_sec=7.0,
                skin_temperature_time_constant_sec=360.0,
            ),
            SimulationScenario.WALKING: ScenarioContext(
                scenario=SimulationScenario.WALKING,
                activity_level=ActivityLevel.MODERATE,
                heart_rate_target_bpm=profile.walking_heart_rate_bpm,
                skin_temperature_target_c=base_temperature - 0.15,
                steps_per_minute=105.0,
                battery_drain_multiplier=1.25,
                heart_rate_time_constant_sec=40.0,
                cadence_time_constant_sec=6.0,
                skin_temperature_time_constant_sec=300.0,
            ),
            SimulationScenario.RUNNING: ScenarioContext(
                scenario=SimulationScenario.RUNNING,
                activity_level=ActivityLevel.HIGH,
                heart_rate_target_bpm=profile.running_heart_rate_bpm,
                skin_temperature_target_c=base_temperature - 0.30,
                steps_per_minute=170.0,
                battery_drain_multiplier=1.70,
                heart_rate_time_constant_sec=62.5,
                cadence_time_constant_sec=7.0,
                skin_temperature_time_constant_sec=300.0,
            ),
            SimulationScenario.EXERCISING: ScenarioContext(
                scenario=SimulationScenario.EXERCISING,
                activity_level=ActivityLevel.HIGH,
                heart_rate_target_bpm=profile.exercising_heart_rate_bpm,
                skin_temperature_target_c=base_temperature - 0.20,
                steps_per_minute=65.0,
                battery_drain_multiplier=1.55,
                heart_rate_time_constant_sec=55.0,
                cadence_time_constant_sec=8.0,
                skin_temperature_time_constant_sec=300.0,
            ),
            SimulationScenario.RECOVERY: ScenarioContext(
                scenario=SimulationScenario.RECOVERY,
                activity_level=ActivityLevel.LIGHT,
                heart_rate_target_bpm=profile.recovery_heart_rate_bpm,
                skin_temperature_target_c=base_temperature - 0.05,
                steps_per_minute=0.0,
                battery_drain_multiplier=1.15,
                # From a typical 145-150 bpm end-run value, tau≈110 s gives
                # a roughly 25-35 bpm first-minute fall rather than an
                # instantaneous return to resting HR.
                heart_rate_time_constant_sec=110.0,
                cadence_time_constant_sec=6.0,
                skin_temperature_time_constant_sec=360.0,
            ),
            SimulationScenario.STRESS_EVENT: ScenarioContext(
                scenario=SimulationScenario.STRESS_EVENT,
                activity_level=ActivityLevel.RESTING,
                heart_rate_target_bpm=profile.stress_heart_rate_bpm,
                skin_temperature_target_c=base_temperature - 0.15,
                steps_per_minute=0.0,
                battery_drain_multiplier=1.05,
                # Acute defensive/startle events are intentionally much
                # faster than exercise onset. With the default 2 s sampling
                # interval this reaches ~120 BPM from rest in about 5-6 s.
                heart_rate_time_constant_sec=1.5,
                cadence_time_constant_sec=7.0,
                skin_temperature_time_constant_sec=240.0,
            ),
            SimulationScenario.OVEREXERTION: ScenarioContext(
                scenario=SimulationScenario.OVEREXERTION,
                activity_level=ActivityLevel.HIGH,
                heart_rate_target_bpm=profile.overexertion_heart_rate_bpm,
                skin_temperature_target_c=base_temperature - 0.35,
                steps_per_minute=195.0,
                battery_drain_multiplier=2.0,
                # Deliberately faster than normal RUNNING for a practical
                # technical alert demonstration. This is not a medical model.
                heart_rate_time_constant_sec=12.0,
                cadence_time_constant_sec=4.0,
                skin_temperature_time_constant_sec=300.0,
            ),
        }

        context = profiles[self._current_scenario]
        return replace(
            context,
            failed_sensor_name=self._failed_sensor_name,
            force_low_battery=self._force_low_battery,
        )
