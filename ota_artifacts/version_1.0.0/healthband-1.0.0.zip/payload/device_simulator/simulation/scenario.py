"""Scenario definitions and simulation context models."""

from dataclasses import dataclass
from enum import StrEnum


class ActivityLevel(StrEnum):
    """Activity levels reported by the simulated HealthBand."""

    SLEEPING = "SLEEPING"
    RESTING = "RESTING"
    LIGHT = "LIGHT"
    MODERATE = "MODERATE"
    HIGH = "HIGH"


class SimulationScenario(StrEnum):
    """Simulation scenarios supported by HealthBand version 1.0.0."""

    SLEEPING = "SLEEPING"
    RESTING = "RESTING"
    WALKING = "WALKING"
    RUNNING = "RUNNING"
    EXERCISING = "EXERCISING"
    RECOVERY = "RECOVERY"
    STRESS_EVENT = "STRESS_EVENT"
    OVEREXERTION = "OVEREXERTION"

    # Technical fault/demo overlays. They intentionally remain part of the
    # public scenario enum because commands already use these names, but they
    # must never replace the user's physiological activity.
    SENSOR_FAILURE = "SENSOR_FAILURE"
    LOW_BATTERY = "LOW_BATTERY"
    NETWORK_OUTAGE = "NETWORK_OUTAGE"


@dataclass(frozen=True, slots=True)
class ScenarioContext:
    """Parameters that version-1 sensors use to generate simulated values."""

    scenario: SimulationScenario
    activity_level: ActivityLevel

    heart_rate_target_bpm: float
    skin_temperature_target_c: float
    steps_per_minute: float

    battery_drain_multiplier: float

    # Different signals do not react on the same time scale. Keeping these
    # constants in the context lets a scenario describe physiologically smooth
    # transitions without changing the public v1 feature set.
    heart_rate_time_constant_sec: float = 45.0
    cadence_time_constant_sec: float = 8.0
    skin_temperature_time_constant_sec: float = 240.0

    failed_sensor_name: str | None = None
    force_low_battery: bool = False
