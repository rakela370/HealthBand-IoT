"""Registration and coordinated reading of HealthBand version-1 sensors."""

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any

from device_simulator.sensors.base_sensor import BaseSensor
from device_simulator.sensors.battery_model import BatteryModel
from device_simulator.sensors.heart_rate_sensor import HeartRateSensor
from device_simulator.sensors.skin_temperature_sensor import SkinTemperatureSensor
from device_simulator.sensors.step_counter_sensor import StepCounterSensor
from device_simulator.simulation.scenario import ScenarioContext
from device_simulator.simulation.signal_generator import SignalGenerator
from device_simulator.simulation.user_profile import UserProfile


@dataclass(frozen=True, slots=True)
class SensorSnapshot:
    """Combined measurements produced during one sampling cycle."""

    measurements: dict[str, Any]
    sensor_status: dict[str, str]
    scenario: str
    activity_level: str
    timestamp: datetime


class SensorManager:
    """Register, control and read all HealthBand v1 sensors."""

    def __init__(
        self,
        user_profile: UserProfile | None = None,
        random_seed: int | None = None,
    ) -> None:
        profile = user_profile or UserProfile()
        generator = SignalGenerator(seed=random_seed)

        self._sensors: dict[str, BaseSensor] = {}
        self._scenario_failed_sensor: str | None = None

        self.register(
            HeartRateSensor(
                signal_generator=generator,
                user_profile=profile,
            )
        )
        self.register(
            SkinTemperatureSensor(
                signal_generator=generator,
                user_profile=profile,
            )
        )
        self.register(
            StepCounterSensor(
                signal_generator=generator,
                timezone_name=profile.timezone_name,
            )
        )
        self.register(BatteryModel())

    @property
    def sensors(self) -> tuple[BaseSensor, ...]:
        """Return all currently registered v1 sensors."""

        return tuple(self._sensors.values())

    def register(self, sensor: BaseSensor) -> None:
        """Register one sensor with the manager."""

        if sensor.name in self._sensors:
            raise ValueError(f"Sensor '{sensor.name}' is already registered.")
        self._sensors[sensor.name] = sensor

    def has_sensor(self, name: str) -> bool:
        """Return whether a v1 sensor exists."""

        return name in self._sensors

    def get_sensor(self, name: str) -> BaseSensor:
        """Return a registered sensor by name."""

        try:
            return self._sensors[name]
        except KeyError as exc:
            raise KeyError(f"Unknown sensor '{name}'.") from exc

    def read_all(
        self,
        context: ScenarioContext,
        elapsed_sec: float,
    ) -> SensorSnapshot:
        """Read sensors without allowing technical faults to change activity."""

        self._apply_scenario_failure(context.failed_sensor_name)

        measurements: dict[str, Any] = {}
        statuses: dict[str, str] = {}

        for sensor in self._sensors.values():
            reading = sensor.read(context=context, elapsed_sec=elapsed_sec)
            statuses[sensor.name] = reading.status.value
            if reading.valid:
                measurements.update(reading.values)

        measurements["activityLevel"] = context.activity_level.value

        return SensorSnapshot(
            measurements=measurements,
            sensor_status=statuses,
            scenario=context.scenario.value,
            activity_level=context.activity_level.value,
            timestamp=datetime.now(timezone.utc),
        )

    def _apply_scenario_failure(self, failed_sensor_name: str | None) -> None:
        """Apply a requested failure; never auto-heal it on activity change."""

        if failed_sensor_name is None:
            return

        sensor = self.get_sensor(failed_sensor_name)
        sensor.simulate_failure()
        self._scenario_failed_sensor = failed_sensor_name

    def simulate_sensor_failure(self, name: str) -> None:
        """Put one v1 sensor into FAILED state."""

        self.get_sensor(name).simulate_failure()
        self._scenario_failed_sensor = name

    def restore_sensor(self, name: str) -> None:
        """Restore one v1 sensor explicitly."""

        self.get_sensor(name).restore()
        if self._scenario_failed_sensor == name:
            self._scenario_failed_sensor = None

    def sensor_statuses(self) -> dict[str, str]:
        """Return technical status of every registered sensor."""

        return {
            name: sensor.status.value
            for name, sensor in self._sensors.items()
        }

    def export_runtime_state(self) -> dict[str, Any]:
        """Return restart-safe canonical state for stateful v1 sensors."""

        state: dict[str, Any] = {}

        heart = self.get_sensor("heart_rate")
        if isinstance(heart, HeartRateSensor):
            state["heartRateBpm"] = heart.current_bpm

        temperature = self.get_sensor("skin_temperature")
        if isinstance(temperature, SkinTemperatureSensor):
            state["skinTemperatureCelsius"] = temperature.current_celsius

        steps = self.get_sensor("step_counter")
        if isinstance(steps, StepCounterSensor):
            state.update(
                {
                    "totalDailySteps": steps.total_daily_steps,
                    "fractionalSteps": steps.fractional_steps,
                    "cadenceStepsPerMinute": steps.current_cadence,
                    "stepsLocalDate": steps.local_date,
                }
            )

        battery = self.get_sensor("battery")
        if isinstance(battery, BatteryModel):
            state["batteryPercentage"] = battery.percentage
            state["charging"] = battery.charging

        state["failedSensors"] = [
            name
            for name, sensor in self._sensors.items()
            if sensor.status.value == "FAILED"
        ]

        return state

    def restore_runtime_state(self, state: dict[str, Any]) -> None:
        """Restore state saved by v1 or a compatible later release."""

        heart = self.get_sensor("heart_rate")
        if isinstance(heart, HeartRateSensor) and state.get("heartRateBpm") is not None:
            heart.restore_runtime_value(float(state["heartRateBpm"]))

        temperature = self.get_sensor("skin_temperature")
        if (
            isinstance(temperature, SkinTemperatureSensor)
            and state.get("skinTemperatureCelsius") is not None
        ):
            temperature.restore_runtime_value(float(state["skinTemperatureCelsius"]))

        steps = self.get_sensor("step_counter")
        if isinstance(steps, StepCounterSensor):
            steps.restore_runtime_state(
                total_daily_steps=int(state.get("totalDailySteps", 0)),
                fractional_steps=float(state.get("fractionalSteps", 0.0)),
                cadence_steps_per_minute=float(
                    state.get("cadenceStepsPerMinute", 0.0)
                ),
                local_date=(
                    str(state["stepsLocalDate"])
                    if state.get("stepsLocalDate")
                    else None
                ),
            )

        battery = self.get_sensor("battery")
        if isinstance(battery, BatteryModel) and state.get("batteryPercentage") is not None:
            battery.restore_runtime_state(
                percentage=float(state["batteryPercentage"]),
                charging=bool(state.get("charging", False)),
            )

        for sensor_name in state.get("failedSensors", []):
            if isinstance(sensor_name, str) and self.has_sensor(sensor_name):
                self.simulate_sensor_failure(sensor_name)
